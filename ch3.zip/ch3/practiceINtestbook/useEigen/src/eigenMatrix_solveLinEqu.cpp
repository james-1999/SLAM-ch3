#include<iostream>
#include<ctime>
using namespace std;

#include<Eigen/Core>
#include<Eigen/Dense>
using namespace Eigen;

#define MATRIX_SIZE 3

int main(int argc, char const *argv[])
{
    clock_t time_stt=clock();
    for(int i=0;i<100000;i++){ };
    cout<<1000*(clock()-time_stt)/(double)CLOCKS_PER_SEC<<"ms"<<endl;

    MatrixXd matrix_NN = Matrix<double,MATRIX_SIZE,MATRIX_SIZE>::Random();

    matrix_NN=matrix_NN.transpose()*matrix_NN;  //构造半正定
    cout<<matrix_NN.cols()<<endl;

    VectorXd v_Nd=VectorXd::Random(MATRIX_SIZE);

    time_stt=clock();
    MatrixXd x=matrix_NN.inverse()*v_Nd;
    cout<<x<<endl;
    cout<< 1000*(clock()-time_stt)/(double)CLOCKS_PER_SEC <<"ms"<<endl;

    time_stt=clock();
    cout<<matrix_NN.colPivHouseholderQr().solve(v_Nd)<<endl;
    cout<< 1000*(clock()-time_stt)/(double)CLOCKS_PER_SEC <<"ms"<<endl;

    time_stt=clock();
    cout<<matrix_NN.ldlt().solve(v_Nd)<<endl;
    cout<< 1000*(clock()-time_stt)/(double)CLOCKS_PER_SEC <<"ms"<<endl;

    return 0;
}
