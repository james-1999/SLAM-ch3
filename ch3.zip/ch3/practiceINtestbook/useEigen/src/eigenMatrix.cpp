#include <iostream>
using namespace std;
#include <ctime>

#include <vector>

#include <Eigen/Core>
#include <Eigen/Dense>
using namespace Eigen;

#define MATRIX_SIZE 50

// template<typename T,int col>  // 测试 通过模板传变量
// void func()
// {
//     cout<<col<<endl;
// }

int main(int argc, char const *argv[])
{
    Matrix<float,2,3> matrix_23;
    matrix_23<<1,2,3,4,5,6;
    cout<<matrix_23<<endl;
    cout<<matrix_23(1,2)<<endl;
    vector<int> v1{1,2,3};
    cout<<v1[0]<<endl;
    Matrix<double,Dynamic,Dynamic> m33_0 = Matrix3d::Zero();
    cout<<m33_0<<endl;

    Vector3d v_3d=Vector3d::Zero();
    v_3d<<1.2,2,1;
    cout<<v_3d<<endl;

    Vector3i v_3dint=v_3d.cast<int>();
    cout<<v_3dint<<endl;

    cout<<"--------------------------------"<<endl;
    // Matrix<double,3,3> matrix_33=Matrix3d::Random();
    Matrix3d matrix_33;
    matrix_33<<1,5,6,5,4,2,6,2,3;
    cout<<matrix_33<<endl<<"\n";
    cout<<matrix_33.transpose()<<endl<<"\n";
    cout<<matrix_33.sum()<<endl;
    cout<<matrix_33.trace()<<endl;
    cout<<matrix_33*10<<endl<<endl;
    cout<<matrix_33.inverse()<<endl<<"\n";
    cout<<matrix_33.determinant()<<endl<<endl;

    //特征值eig
    cout<<"------------------------------"<<endl;
    cout<<matrix_33.transpose()*matrix_33<<endl;
    EigenSolver<Matrix3d> eigen_sorver(matrix_33.transpose()*matrix_33);
    cout<<eigen_sorver.eigenvalues()<<endl;
    cout<<eigen_sorver.eigenvectors()<<endl;
    SelfAdjointEigenSolver<Matrix3d> eigen_sorver2(matrix_33.transpose()*matrix_33);
    cout<<eigen_sorver2.eigenvalues()<<endl;
    cout<<eigen_sorver2.eigenvectors()<<endl;
    cout<<(matrix_33.transpose()*matrix_33).eigenvalues()<<endl;

    MatrixXd result=(eigen_sorver2.eigenvectors()*eigen_sorver2.eigenvalues().asDiagonal()*eigen_sorver2.eigenvectors().inverse()).cast<double>();
    cout<<result<<endl;

    Matrix3d matrix_33_2;
    matrix_33_2<<1,0,0, 0,2,0, 0,0,3;
    VectorXd v_3=matrix_33_2.diagonal(); 
    cout<<v_3.transpose()<<endl;
    cout<<v_3.asDiagonal().toDenseMatrix()<<endl;
    return 0;
}
