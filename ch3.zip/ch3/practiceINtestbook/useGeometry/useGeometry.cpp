#include<iostream>
#include<cmath>
using namespace std;

#include<Eigen/Core>
#include<Eigen/Geometry>
using namespace Eigen;

int main(int argc, char const *argv[])
{
    //AngelAxis to matrix
    Matrix3d rotation_matrix=Matrix3d::Identity();
    AngleAxisd rotation_vector(M_PI/4, Vector3d(0,0,1));
    cout.precision(3);
    cout<<rotation_vector.matrix()<<endl;
    cout<<rotation_vector.toRotationMatrix()<<endl;
    rotation_matrix=rotation_vector.matrix();
    //matrix to AngelAxis
    AngleAxisd rot_form_matrix;
    rot_form_matrix.fromRotationMatrix(rotation_matrix);
    cout<<"Angle:"<<rot_form_matrix.angle()<<" Axis:"<<rot_form_matrix.axis().transpose()<<endl;
    //matrix to eulerAngles
    cout<<rotation_matrix.eulerAngles(2,1,0)<<endl;
    
    Quaterniond q;
    q=rotation_matrix;
    q=rotation_vector;
    cout<<q.coeffs()<<endl;
    cout<<q.toRotationMatrix()<<endl;
    cout<<"---------------坐标变幻-------------"<<endl;
    //坐标变换
    Vector3d v(1,0,0);
    Vector3d v_rotated=rotation_vector*v;
    cout<<v_rotated.transpose()<<endl;

    v_rotated=rotation_matrix*v;
    cout<<v_rotated.transpose()<<endl;

    v_rotated=q*v;
    cout<<v_rotated.transpose()<<endl;
    cout<<(q*Quaterniond(0,1,0,0)*q.inverse()).coeffs().transpose()<<endl;
    
    cout<<"--------------"<<endl;
    Isometry3d T=Isometry3d::Identity();
    T.rotate<AngleAxisd>(rotation_vector);
    T.pretranslate<Vector3d>(Vector3d(1,3,4));
    cout<<T.matrix()<<endl;
    cout<<(T*v).transpose()<<endl;
    
    return 0;
}
