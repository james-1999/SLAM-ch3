// #include<unistd.h>
#include<iostream>
#include<string>
#include<fstream>
#include<vector>
#include<Eigen/Core>
#include<Eigen/Geometry>
using namespace Eigen;
using namespace std;

string trajectory_file="./mytxt.txt";

int main(int argc, char const *argv[])
{
    fstream f(trajectory_file,ios::app);
    if(f)
    {
        cout<<"opened!!!!!!!1"<<endl;
        cout<<f.is_open()<<endl;
        cout<<f.eof()<<endl;
        
    }
    f<<"bbbb";
    // char a[10]={0};
    // cin>>a[0]>>a[1]>>a[2];
    // cout<<endl<<a[0]<<a[1]<<a[2];
    vector<int> v1{1,2,3,4};
    Vector3d v11(1,2,3);
    
    Isometry3d Twr;
    Vector3d Ow=Twr.translation();
    Twr.rotation();
    return 0;
}
