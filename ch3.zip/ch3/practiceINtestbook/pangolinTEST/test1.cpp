#include<pangolin/pangolin.h>
// #include<Eigen/Core>
#include<unistd.h>
using namespace std;
using namespace Eigen;


int main(int argc, char const *argv[])
{
    cout<<"hello"<<endl;
    pangolin::CreateWindowAndBind("main",640,480);
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);

    pangolin::OpenGlRenderState s_cam(
    pangolin::ProjectionMatrix(1024, 768, 500, 500, 512, 389, 0.1, 1000),
    pangolin::ModelViewLookAt(0, -0.1, -1.8, 0, 0, 0, 0.0, -1.0, 0.0)
    );
    pangolin::View &d_cam = pangolin::CreateDisplay()
    .SetBounds(0.0, 1.0, 0.0, 1.0, -1024.0f / 768.0f)
    .SetHandler(new pangolin::Handler3D(s_cam));

  
    while(pangolin::ShouldQuit()==false)
    {
        glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
        d_cam.Activate(s_cam);
        // pangolin::glDrawColouredCube();
        glClearColor(1,1,1,1);

        glLineWidth(5);
        glPointSize(10);
        glBegin(GL_LINES);  
        glColor3f(1.0,0.0,0.0);
        glVertex3d(0,0,0);
        glVertex3d(1,1,1);
                
        glVertex3d(5,5,5);
        glVertex3d(0,1,1);
        glEnd();

        pangolin::FinishFrame();
        usleep(5000);
        
    }
    
    return 0;
}
