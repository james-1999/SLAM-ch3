#include<pangolin/pangolin.h>
#include<fstream>
#include<string>
#include<unistd.h>
#include<Eigen/Core>

#include<Eigen/Geometry>
using namespace std;
using namespace Eigen;

string trajectory_file="../trajectory.txt";  //相对路径都是工作空间下的，而不是当前文件的相对路径

void DrawTrajectory(vector<Isometry3d> & Twr)
{
    pangolin::CreateWindowAndBind("main",1024,768);
    glEnable(GL_DEPTH_TEST);   //增加视觉深度效果  
    glEnable(GL_BLEND);     
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    //静态视角（相机）  
    pangolin::OpenGlRenderState s_cam(     
    pangolin::ProjectionMatrix(1024, 768, 500, 500, 512, 389, 0.1, 1000),
    pangolin::ModelViewLookAt(0, -0.1, -1.8, 0, 0, 0, 0.0, -1.0, 0.0)
     );
    //鼠标交互功能，动态视角（相机）
    pangolin::View &d_cam = pangolin::CreateDisplay().SetBounds(0.0, 1.0, 0.0, 1.0, -1024.0f / 768.0f).SetHandler(new pangolin::Handler3D(s_cam));

    while(pangolin::ShouldQuit()==false)
    {
        glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);  //每次画的时候都要清理掉上一次的痕迹，不然会不断叠加 至于为什么只要清理这两个buffer我也不知道
        glClearColor(1,1,1,1); //重新设置背景色，rgba a貌似是透明度
        d_cam.Activate(s_cam); //重新激活交互，激活视角转变。每次pangolin::FinishFrame()之后都会关闭交互

        //开始画线
        glLineWidth(2);
        for(int i=0;i<Twr.size();i++)
        {
            Vector3d Ow = Twr[i].translation();
            Vector3d Xw = Twr[i]*(Vector3d(1,0,0)*0.1); //matrix().block(0,0,3,1);
            Vector3d Yw = Twr[i]*(Vector3d(0,1,0)*0.1);
            Vector3d Zw = Twr[i]*(Vector3d(0,0,1)*0.1);
            // cout<<Twr[i].matrix()<<endl;
            // cout<<Ow.transpose()<<endl;
            // cout<<Ow(0)<<endl;   
            glBegin(GL_LINES);
            glColor3f(1,0,0);
            glVertex3d(Ow[0],Ow[1],Ow[2]);    //注意所有向量矩阵都从0开始
            glVertex3d(Xw[0],Xw[1],Xw[2]);    
            
            glColor3f(0,1,0);
            glVertex3d(Ow[0],Ow[1],Ow[2]);    //注意所有向量矩阵都从0开始
            glVertex3d(Yw(0,0),Yw(1,0),Yw(2,0));    // () 还是[] 无所谓

            glColor3f(0,0,1);
            glVertex3d(Ow[0],Ow[1],Ow[2]);    //注意所有向量矩阵都从0开始
            glVertex3d(Zw[0],Zw[1],Zw[2]); 
            glEnd();

        }
        
        for(int i=0;i<Twr.size();i++)
        {
            glColor3f(0,0,0);
            glBegin(GL_LINES);
            auto p1=Twr[i],p2=Twr[i+1];
            glVertex3d(p1.translation()[0],p1.translation()[1],p1.translation()[2]);
            glVertex3d(p2.translation()[0],p2.translation()[1],p2.translation()[2]);
            glEnd();
        }


        pangolin::FinishFrame();  //更新图窗

    }
}

int main(int argc, char const *argv[])
{
    cout<<"hello pangolin"<<endl;
    
    fstream fin(trajectory_file);
    if(fin.is_open()==false)
    {
        cout<<"找不到trajectory at"<<trajectory_file<<endl;
    }
    else {cout<<"找到了trajectory"<<endl;}

    double time,tx,ty,tz,qx,qy,qz,qw;
    vector<Isometry3d> Twr;
    Isometry3d Ttemp=Isometry3d::Identity();  //赋初值很重要 不然随机值。
    while(fin.eof()==false)
    {
        fin>>time>>tx>>ty>>tz>>qx>>qy>>qz>>qw;
        Ttemp=Isometry3d::Identity();   // 每次都要清空，不然就是在上一次旋转上面的叠加
        Ttemp.rotate(Quaterniond(qw,qx,qy,qz));
        Ttemp.pretranslate(Vector3d(tx,ty,tz));
        // cout<<Ttemp.matrix()<<endl;
        Twr.push_back(Ttemp);
    }
    cout<<"read total "<<Twr.size()<<" pose entries"<<endl;
    fin.close();
    DrawTrajectory(Twr);
    

    return 0;
}
