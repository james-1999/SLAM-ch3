#include<iostream>
#include<cmath>
using namespace std;

#include<Eigen/Core>
#include<Eigen/Geometry>
using namespace Eigen;


int main(int argc, char const *argv[])
{
    cout<<"hello"<<endl;
    Quaterniond q1(0.35,0.2,0.3,0.1),q2(-0.5,0.4,-0.1,0.2);
    q1.normalize();
    q2.normalize();
    Vector3d t1(0.3,0.1,0.1),t2(-0.1,0.5,0.3);
    
    Isometry3d T1w(Isometry3d::Identity()),T2w(Isometry3d::Identity());
    // Isometry3d T1w,T2w;
    cout<<T1w.matrix()<<endl;
    T1w.rotate(q1); 
    cout<<endl<<T1w.matrix()<<endl;
    T1w.pretranslate(t1);
    T2w.rotate(q2); 
    T2w.pretranslate(t2);

    Vector3d p1(0.5,0,0.2);

    cout.precision(5);
    Vector3d p2 = T2w*T1w.inverse()*p1;
    cout<<p2.transpose()<<endl;

    return 0;
}
