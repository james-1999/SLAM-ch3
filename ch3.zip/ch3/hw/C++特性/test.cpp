#include<iostream>
#include<vector>
#include<algorithm>
using namespace std;

int main(int argc, char const *argv[])
{
    vector<int> vint{1,2,1,4,3};
    for_each(vint.begin(),vint.end(),[](decltype(vint[0]) & a){cout<<a<<" ";});
    
    for(int & a :vint)
    {
        cout<<a<<endl;
    }

    sort(vint.begin(),vint.end(),[](auto & a1,auto & a2) {return a1<a2;});
    for_each(vint.begin(),vint.end(),[](auto &a) {cout<<a<<" ";});
    return 0;
}
