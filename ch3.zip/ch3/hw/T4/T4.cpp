#include<Eigen/Core>
#include<Eigen/Geometry>
using namespace Eigen;
#include<pangolin/pangolin.h>
using namespace std;

template<typename vectorType>
void DrawCoordinate(vector<vectorType> & coordVector)
{
    pangolin::CreateWindowAndBind("main",1024,768);
    glEnable(GL_DEPTH_TEST);   //增加视觉深度效果  
    glEnable(GL_BLEND);     
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    //静态视角（相机）  
    pangolin::OpenGlRenderState s_cam(     
    pangolin::ProjectionMatrix(1024, 768, 500, 500, 512, 389, 0.1, 1000),
    pangolin::ModelViewLookAt(0, -0.1, -1.8, 0, 0, 0, 0.0, -1.0, 0.0)
     );
    //鼠标交互功能，动态视角（相机）
    pangolin::View &d_cam = pangolin::CreateDisplay().SetBounds(0.0, 1.0, 0.0, 1.0, -1024.0f / 768.0f).SetHandler(new pangolin::Handler3D(s_cam));

    while(pangolin::ShouldQuit()==false)
    {
        glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);  //每次画的时候都要清理掉上一次的痕迹，不然会不断叠加 至于为什么只要清理这两个buffer我也不知道
        glClearColor(1,1,1,1); //重新设置背景色，rgba a貌似是透明度
        d_cam.Activate(s_cam); //重新激活交互，激活视角转变。每次pangolin::FinishFrame()之后都会关闭交互

        //开始画线
        glLineWidth(2);
        glBegin(GL_LINES);
        glColor3f(1,0,0);
        glVertex3d(0,0,0);
        glVertex3d(10,0,0);

        glColor3f(0,1,0);
        glVertex3d(0,0,0);
        glVertex3d(0,10,0);

        glColor3f(0,0,1);
        glVertex3d(0,0,0);
        glVertex3d(0,0,10);
        glEnd();

        for(int i=0;i<coordVector.size();i++)
        {
            Vector3d Ow = coordVector[i].translation();
            Vector3d Xw = coordVector[i]*(Vector3d(1,0,0)*0.1); //matrix().block(0,0,3,1);
            Vector3d Yw = coordVector[i]*(Vector3d(0,1,0)*0.1);
            Vector3d Zw = coordVector[i]*(Vector3d(0,0,1)*0.1);
            // cout<<Twr[i].matrix()<<endl;
            // cout<<Ow.transpose()<<endl;
            // cout<<Ow(0)<<endl;   
            glBegin(GL_LINES);
            glColor3f(1,0,0);
            glVertex3d(Ow[0],Ow[1],Ow[2]);    //注意所有向量矩阵都从0开始
            glVertex3d(Xw[0],Xw[1],Xw[2]);    
            
            glColor3f(0,1,0);
            glVertex3d(Ow[0],Ow[1],Ow[2]);    //注意所有向量矩阵都从0开始
            glVertex3d(Yw(0,0),Yw(1,0),Yw(2,0));    // () 还是[] 无所谓

            glColor3f(0,0,1);
            glVertex3d(Ow[0],Ow[1],Ow[2]);    //注意所有向量矩阵都从0开始
            glVertex3d(Zw[0],Zw[1],Zw[2]); 
            glEnd();

        }
        
        pangolin::FinishFrame();  //更新图窗

    }
}


int main(int argc, char const *argv[])
{
    // qWR = [0.55, 0.3, 0.2, 0.2],
    // tWR = [0.1, 0.2, 0.3]， 
    // qRB = [0.99, 0, 0, 0.01], 
    // tRB = [0.05, 0, 0.5]，
    // qBL = [0.3, 0.5, 0, 20.1],
    // tBL = [0.4, 0, 0.5], 
    // qBC = [0.8, 0.2, 0.1, 0.1], 
    // tBC = [0.5, 0.1, 0.5]
    Quaterniond qWR(0.55, 0.3, 0.2, 0.2),qRB(0.99, 0, 0, 0.01),qBL(0.3, 0.5, 0, 20.1),qBC(0.8, 0.2, 0.1, 0.1);
    qWR.normalize(); qRB.normalize();qBL.normalize();qBC.normalize();
    Vector3d tWR(0.1, 0.2, 0.3),tRB(0.05, 0, 0.5),tBL(0.4, 0, 0.5),tBC(0.5, 0.1, 0.5);
    Isometry3d TWR(qWR),TRB(qRB),TBL(qBL),TBC(qBC);
    TWR.pretranslate(tWR); //pre左乘，无pre右乘。
    TRB.pretranslate(tRB);
    TBL.pretranslate(tBL);
    TBC.pretranslate(tBC);
    //
    vector<Isometry3d> coords{TWR,TRB,TBL,TBC}; 
    DrawCoordinate(coords);

    Vector3d pC(0.3, 0.2, 1.2);

    auto pL=TBL.inverse()*TBC*pC;
    cout<<"pL="<<pL.transpose()<<endl;

    auto pW=TWR*TRB*TBC*pC;
    cout<<"pW="<<pW.transpose()<<endl;


    return 0;
}


